//
//  SpikeModel.swift
//  SampleCoreML
//
//  Created by Nikhil Challagulla on 2/10/24.
//

import Foundation


struct Spike: Identifiable {
    var id: String = UUID().uuidString
    var minutes: Int
    var spike: Int
}
