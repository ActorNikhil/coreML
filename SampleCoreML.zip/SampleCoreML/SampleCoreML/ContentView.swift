//
//  ContentView.swift
//  SampleCoreML
//
//  Created by Nikhil Challagulla on 2/4/24.
//

import SwiftUI
import CoreML
import Foundation
import Charts

struct ContentView: View {
    
    @State var text: String = ""
    
    @ObservedObject var viewModel = CoreMLViewModel()
    
    var body: some View {
        VStack(spacing: 0) {
            Spacer()

//            VStack {
//                Spacer()
//                
//                Text("Highest Spike level")
//                    .font(.system(size: 25))
//                    .padding()
//
//                
//                Text("245")
//                    .font(.system(size: 80))
//                    .padding()
//
//
//                
//                Spacer()
//            }
//            .background(.red)
//            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height * 0.2)

            
            VStack {
                Spacer()
                
                Chart(viewModel.spikes) {
                    LineMark(
                        x: PlottableValue.value("minutes", $0.minutes),
                        y: PlottableValue.value("Spike", $0.spike)
                    )
                    .lineStyle(StrokeStyle(lineWidth: 4.0))
                    
                    RuleMark(y: .value("Break Even Threshold", 175))
                        .foregroundStyle(.red)
                    
                    RuleMark(y: .value("Break Even Threshold", 60))
                        .foregroundStyle(.red)
                }
                
                Spacer()
            }
            .background(.white)
            .frame(height: UIScreen.main.bounds.height * 0.8)
            
            VStack {
                Spacer()
                
                TextField("enter crabs count", text: $text)
                    .padding()
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Button {
                  //  viewModel.updateChart(carbs: text)
                    
                    viewModel.testData(text)
                    
                } label: {
                    Spacer()
                    Text("Submit")
                    Spacer()
                }
                .buttonStyle(.borderedProminent)
                .padding()
                
                Spacer()
            }
            .background(.yellow)
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height * 0.2)
            
        }
        .edgesIgnoringSafeArea(.all)
        .onAppear {
        }
    }
}
