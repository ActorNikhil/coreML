//
//  SampleCoreMLApp.swift
//  SampleCoreML
//
//  Created by Nikhil Challagulla on 2/4/24.
//

import SwiftUI

@main
struct SampleCoreMLApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
