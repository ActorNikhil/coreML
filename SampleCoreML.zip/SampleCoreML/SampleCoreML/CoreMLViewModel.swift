//
//  CoreMLViewModel.swift
//  SampleCoreML
//
//  Created by Nikhil Challagulla on 2/10/24.
//

import Foundation
import CoreML

class CoreMLViewModel: ObservableObject {
    
    @Published var spikes: [Spike] = []
    
    func updateChart(carbs: String) {
        if Int(carbs) ?? 0 > 100 && Int(carbs) ?? 0 < 200 {
            spikes = [
                Spike(minutes: 0, spike: 90),
                Spike(minutes: 30, spike: 165),
                Spike(minutes: 60, spike: 165),
                Spike(minutes: 90, spike: 120),
                Spike(minutes: 120, spike: 95)
            ]
        } else {
            spikes = [
                Spike(minutes: 0, spike: 190),
                Spike(minutes: 30, spike: 265),
                Spike(minutes: 60, spike: 265),
                Spike(minutes: 90, spike: 220),
                Spike(minutes: 120, spike: 95)
            ]
        }
    } // these is custom  data to show the graph 
    
    func testData(_ text: String) {
        let configuration = MLModelConfiguration()
        do {
            let model = try Spike2(configuration: configuration)
            
            let prediction = try model.prediction(_10: Double(text) ?? 0)
            // Use the prediction output
            print(prediction._90)
        } catch {
            // Handle the error
            print("Prediction error: \(error)")
        }
    }
    
    func grabBundleURL() {
        let bundle = Bundle(for: Spike2.self)
        
        let updatableModelURL = bundle.url(forResource: "Spike2", withExtension: "mlpackage")
    }
    
    
    func featuresFromMealAndKeywords(meal: String, keywords: [String]) -> [String: Double] {
        let featureNames =  keywords + keywords.map { meal + ":" + $0 }
        
        return featureNames.reduce(into: [:]) { features, name in
            features[name] = 1.0
        }
    }
    
    var trainingKeywords: [[String: Double]] = []
                           
    var trainingTargets: [Double] = []
    
//    func prepareTrainingData(userPurchasedItems: [[String: Double]]) {
//        
//        for item in userPurchasedItems {
//            
//            trainingKeywords.append(featuresFromMealAndKeywords(meal: item.meal, keywords: item.keywords))
//            trainingTargets.append(1.0)
//            
//            
//            let negativeKeywords = allkeyWords.subtracting(item.keywods)
//            
//            trainingKeywords.append(featuresFromMealAndKeywords(meal: item.meal, keywords: Array(negativeKeywords)))
//            
//            trainingTargets.append(-1.0)            
//        }
//    }
    
    
//    func prepareTrainingData() {
//        
//        //let mlArray =  try! MLMultiArray(data)
//        
//        let singleTrainingData = UpdatableKNNTrainingInput
//    }
    
}
